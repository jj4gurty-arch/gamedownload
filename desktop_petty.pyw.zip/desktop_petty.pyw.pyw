import tkinter as tk
import random
import time

# -----------------------------
# CONFIG
# -----------------------------
SKINS = {
    "Cat": ["🐱", "😺", "😸", "😼"],
    "Dog": ["🐶", "🐕", "🦮", "🐩"],
    "Blob": ["🟢", "🟡", "🟣", "🔵"],
    "Ghost": ["👻", "💀", "👻", "💀"],
    "Robot": ["🤖", "🟦", "🤖", "🟦"]
}

MEMES = [
    "You got games on your phone? 📱",
    "Feed me now 🍔",
    "Pet is judging you 👀",
    "Skill issue detected 🎮",
    "Pet wants pizza 🍕",
    "Touch grass 🌱",
    "You forgot to save 💀"
]

class DesktopPet:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.geometry("120x120+300+300")
        self.root.attributes("-topmost", True)
        self.root.config(bg="white")

        # -----------------------------
        # PET STATE
        # -----------------------------
        self.skin = "Cat"
        self.frames = SKINS[self.skin]
        self.frame_index = 0

        self.personality = "Happy"  # Happy, Bored, Angry, Sleepy
        self.last_interaction = time.time()

        self.hunger = 100
        self.sleeping = False
        self.chasing_mouse = False
        self.come_here_mode = False

        # -----------------------------
        # UI
        # -----------------------------
        self.pet_label = tk.Label(
            self.root,
            text=self.frames[0],
            font=("Arial", 50),
            bg="white"
        )
        self.pet_label.pack(expand=True)

        # Speech bubble
        self.bubble = tk.Label(
            self.root,
            text="",
            font=("Arial", 9, "bold"),
            bg="yellow",
            bd=2,
            relief="solid"
        )

        # Dragging
        self.pet_label.bind("<Button-1>", self.start_move)
        self.pet_label.bind("<B1-Motion>", self.do_move)

        # -----------------------------
        # FOOD DRAG ICON
        # -----------------------------
        self.food_icon = tk.Label(
            self.root,
            text="🍔",
            font=("Arial", 20),
            bg="white"
        )
        self.food_icon.place(x=40, y=90)
        self.food_icon.bind("<Button-1>", self.start_food_drag)
        self.food_icon.bind("<B1-Motion>", self.drag_food)

        # -----------------------------
        # MENU
        # -----------------------------
        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="🍔 Feed", command=self.feed_pet)
        self.menu.add_command(label="😴 Sleep", command=self.sleep_pet)
        self.menu.add_command(label="🌞 Wake", command=self.wake_pet)
        self.menu.add_command(label="😂 Meme", command=self.show_meme)
        self.menu.add_command(label="🖱️ Chase Mouse", command=self.toggle_chase)
        self.menu.add_command(label="📣 Come Here", command=self.call_pet)
        self.menu.add_command(label="🐭 Mini‑Game", command=self.spawn_mouse)
        self.menu.add_separator()

        # Skin submenu
        skin_menu = tk.Menu(self.menu, tearoff=0)
        for skin in SKINS:
            skin_menu.add_command(label=skin, command=lambda s=skin: self.change_skin(s))
        self.menu.add_cascade(label="🎨 Skin", menu=skin_menu)

        self.menu.add_separator()
        self.menu.add_command(label="❌ Close", command=self.root.destroy)

        self.pet_label.bind("<Button-3>", self.show_menu)

        # -----------------------------
        # MOVEMENT
        # -----------------------------
        self.dx = random.choice([-3, -2, 2, 3])
        self.dy = random.choice([-3, -2, 2, 3])
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()

        # Mini‑game mouse
        self.game_mouse = None

        # -----------------------------
        # START SYSTEMS
        # -----------------------------
        self.animate_idle()
        self.move_pet()
        self.hunger_system()
        self.random_memes()
        self.personality_system()
        self.day_night_cycle()

        self.root.mainloop()

    # -----------------------------
    # IDLE ANIMATION
    # -----------------------------
    def animate_idle(self):
        if not self.sleeping:
            self.frame_index = (self.frame_index + 1) % len(self.frames)
            self.pet_label.config(text=self.frames[self.frame_index])
        self.root.after(350, self.animate_idle)

    # -----------------------------
    # MOVEMENT
    # -----------------------------
    def move_pet(self):
        if not self.sleeping:
            x = self.root.winfo_x()
            y = self.root.winfo_y()

            # Come here mode
            if self.come_here_mode:
                mx = self.root.winfo_pointerx()
                my = self.root.winfo_pointery()
                x += (mx - x) * 0.05
                y += (my - y) * 0.05

            # Chase mouse
            elif self.chasing_mouse:
                mx = self.root.winfo_pointerx()
                my = self.root.winfo_pointery()
                x += (mx - x) * 0.04
                y += (my - y) * 0.04

            # Mini‑game mouse
            elif self.game_mouse:
                mx = self.game_mouse.winfo_x()
                my = self.game_mouse.winfo_y()
                x += (mx - x) * 0.03
                y += (my - y) * 0.03

                # Collision
                if abs(mx - x) < 40 and abs(my - y) < 40:
                    self.show_message("Got it! 🐭")
                    self.game_mouse.destroy()
                    self.game_mouse = None

            else:
                x += self.dx
                y += self.dy

            # Bounce
            if x <= 0 or x >= self.screen_width - 120:
                self.dx *= -1
            if y <= 0 or y >= self.screen_height - 120:
                self.dy *= -1

            self.root.geometry(f"+{int(x)}+{int(y)}")

        self.root.after(30, self.move_pet)

    # -----------------------------
    # PERSONALITY SYSTEM
    # -----------------------------
    def personality_system(self):
        idle_time = time.time() - self.last_interaction

        if idle_time > 40:
            self.personality = "Bored"
            self.show_message("I'm bored... 🥱")
        elif self.hunger < 30:
            self.personality = "Angry"
        elif self.sleeping:
            self.personality = "Sleepy"
        else:
            self.personality = "Happy"

        self.root.after(5000, self.personality_system)

    # -----------------------------
    # HUNGER
    # -----------------------------
    def hunger_system(self):
        if not self.sleeping:
            self.hunger -= 5
            if self.hunger <= 30:
                self.show_message("I'm hungry!! 🍔")
        self.root.after(7000, self.hunger_system)

    # -----------------------------
    # SPEECH BUBBLE
    # -----------------------------
    def show_message(self, text):
        self.bubble.config(text=text)
        self.bubble.place(x=0, y=-25)
        self.fade_bubble(1.0)

    def fade_bubble(self, opacity):
        if opacity <= 0:
            self.bubble.place_forget()
            return
        color = int(255 * opacity)
        self.bubble.config(fg=f"#{color:02x}0000")
        self.root.after(80, lambda: self.fade_bubble(opacity - 0.1))

    # -----------------------------
    # MENU
    # -----------------------------
    def show_menu(self, event):
        self.menu.post(event.x_root, event.y_root)

    # -----------------------------
    # DRAGGING
    # -----------------------------
    def start_move(self, event):
        self.last_interaction = time.time()
        self.x = event.x
        self.y = event.y

    def do_move(self, event):
        x = event.x_root - self.x
        y = event.y_root - self.y
        self.root.geometry(f"+{x}+{y}")

    # -----------------------------
    # FOOD DRAG
    # -----------------------------
    def start_food_drag(self, event):
        self.fx = event.x
        self.fy = event.y

    def drag_food(self, event):
        x = event.x_root - self.fx
        y = event.y_root - self.fy
        self.food_icon.place(x=x, y=y)

        # Collision with pet
        px = self.root.winfo_x()
        py = self.root.winfo_y()
        if abs(event.x_root - px) < 80 and abs(event.y_root - py) < 80:
            self.feed_pet()

    # -----------------------------
    # ACTIONS
    # -----------------------------
    def feed_pet(self):
        self.hunger = 100
        self.show_message("Yum! 🍔")
        self.last_interaction = time.time()

    def sleep_pet(self):
        self.sleeping = True
        self.pet_label.config(text="😴")
        self.show_message("Zzz...")

    def wake_pet(self):
        self.sleeping = False
        self.show_message("I'm back!")

    def show_meme(self):
        self.show_message(random.choice(MEMES))

    def toggle_chase(self):
        self.chasing_mouse = not self.chasing_mouse
        self.show_message("Chasing mouse! 🖱️" if self.chasing_mouse else "Stopped chasing.")

    def call_pet(self):
        self.come_here_mode = True
        self.show_message("Coming! 🏃‍♂️")
        self.root.after(4000, lambda: setattr(self, "come_here_mode", False))

    # -----------------------------
    # MINI‑GAME
    # -----------------------------
    def spawn_mouse(self):
        if self.game_mouse:
            return

        self.game_mouse = tk.Label(
            self.root,
            text="🐭",
            font=("Arial", 20),
            bg="white"
        )
        self.game_mouse.place(x=random.randint(0, 80), y=random.randint(0, 80))
        self.move_game_mouse()

    def move_game_mouse(self):
        if not self.game_mouse:
            return
        x = random.randint(0, 80)
        y = random.randint(0, 80)
        self.game_mouse.place(x=x, y=y)
        self.root.after(600, self.move_game_mouse)

    # -----------------------------
    # SKINS
    # -----------------------------
    def change_skin(self, skin):
        self.skin = skin
        self.frames = SKINS[skin]
        self.frame_index = 0
        self.show_message(f"Skin: {skin}")

    # -----------------------------
    # RANDOM MEMES
    # -----------------------------
    def random_memes(self):
        self.show_message(random.choice(MEMES))
        self.root.after(15000, self.random_memes)

    # -----------------------------
    # DAY/NIGHT MODE
    # -----------------------------
    def day_night_cycle(self):
        hour = time.localtime().tm_hour
        if 22 <= hour or hour < 6:
            self.sleep_pet()
        self.root.after(60000, self.day_night_cycle)


DesktopPet()